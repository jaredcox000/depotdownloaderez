******************************************************************************************
*                                                                                        *
*  This is just a simple script to make running the DepotDownloader tool a bit easier.   *
*  All you have to know is the version you want to download, and your username/password. *
*                                                                                        *
*  NOTE that if you have Steam Guard, you may be prompted to enter the security code     *
*  sent to your email address.                                                           *
*                                                                                        *
*  COPY COPY COPY "run.bat" to the same location as DepotDownloader.dll. It assumes the  *
*  tool is in the same directory.                                                        *
*                                                                                        *
*  This is intended to be used with the DepotDownloader tool hosted at                   *
*     https://github.com/SteamRE/DepotDownloader/releases                                *
*  to assist downpatching Hollow Knight as explained in this youtube video by fireb0rn   *
*     https://www.youtube.com/watch?v=a-aCaVTAUtc                                        *
*                                                                                        *
******************************************************************************************

When you run the batch file, the first thing it will prompt you for is the version
number you want to install. As of creating this script, these are the valid versions:
  1.0.0.6
  1.0.0.7
  1.0.1.1
  1.0.1.4
  1.0.2.8
  1.0.3.1
  1.0.3.4
  1.0.3.7
  1.1.1.4
  1.1.1.6
  1.1.1.7
  1.1.1.8
  1.2.1.0
  1.2.1.4
  1.2.2.1
  1.3.1.5
  1.4.2.4

Next, it will ask for your username and password. This is required as the DepotDownloader
tool connects to the Steam servers to authenticate your account in order to download
the game.

After entering your username and password, it will ask you to confirm the version.
Just type Y and hit enter if you're ready.

If you have Steam Guard on your account, it will prompt you for the code sent
to your email address before downloading.


And that's it! It will show you during the download progress where it's downloaded to.

******************************************************************************************